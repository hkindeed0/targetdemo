package com.example.demo.model;

public class ProductItemPriceCurrency {

    private Double price;
    private String currencyCode;

    public ProductItemPriceCurrency() {
    }

    public ProductItemPriceCurrency(Double price, String currencyCode) {
        this.currencyCode = currencyCode;
        this.price = price;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }
}