package com.example.demo.model;

import java.util.List;

public class ProductItem {

    private Long id;
    private List<ProductItemPriceCurrency> priceCurrencyList;

    public ProductItem() {

    }

    public ProductItem(Long id, List<ProductItemPriceCurrency> priceCurrencyList) {
        this.id = id;
        this.priceCurrencyList = priceCurrencyList;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<ProductItemPriceCurrency> getPriceCurrencyList() {
        return priceCurrencyList;
    }

    public void setPriceCurrencyList(List<ProductItemPriceCurrency> priceCurrencyList) {
        this.priceCurrencyList = priceCurrencyList;
    }
}
