package com.example.demo.resources;

import com.example.demo.model.ProductItem;
import com.example.demo.model.ProductItemPriceCurrency;
import com.example.demo.service.ProductPriceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/products")
public class ProductCatalog {

    @Autowired
    private ProductPriceService productPriceService;

    @RequestMapping("/{productId}/price")
    public ProductItem getCatalog(@PathVariable ("productId") Long productId) {
        return new ProductItem(productId, productPriceService.getProductPriceCurrencyById(productId));
    }

    @RequestMapping(method = RequestMethod.POST, value = "/{productId}")
    public  void postProductPrice(@RequestBody ProductItemPriceCurrency productItemPriceCurrency, @PathVariable Long productId) {

        productPriceService.updatePrice(productId, productItemPriceCurrency);

    }
}
