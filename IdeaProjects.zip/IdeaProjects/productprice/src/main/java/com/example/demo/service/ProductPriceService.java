package com.example.demo.service;

import com.example.demo.model.ProductItemPriceCurrency;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ProductPriceService {

    private static Map<Long, List<ProductItemPriceCurrency>> productPriceMap;

    public ProductPriceService() {

        buildProductPriceMap();
    }

    private void buildProductPriceMap() {

        List<ProductItemPriceCurrency> priceCurrencyList = new ArrayList<ProductItemPriceCurrency>();
        priceCurrencyList.add(new ProductItemPriceCurrency(100.00, "A-usd"));
        priceCurrencyList.add(new ProductItemPriceCurrency(200.00, "A-cad"));

        productPriceMap = new HashMap<Long, List<ProductItemPriceCurrency>>();
        productPriceMap.put(new Long(1), priceCurrencyList);

        priceCurrencyList = new ArrayList<ProductItemPriceCurrency>();

        priceCurrencyList.add(new ProductItemPriceCurrency(100.00, "B-usd"));
        priceCurrencyList.add(new ProductItemPriceCurrency(200.00, "B-cad"));

        productPriceMap.put(new Long(2), priceCurrencyList);

        priceCurrencyList = new ArrayList<ProductItemPriceCurrency>();
        priceCurrencyList.add(new ProductItemPriceCurrency(100.00, "C-usd"));

        productPriceMap.put(new Long(3), priceCurrencyList);

        priceCurrencyList = new ArrayList<ProductItemPriceCurrency>();
        priceCurrencyList.add(new ProductItemPriceCurrency(100.00, "D-usd"));

        productPriceMap.put(new Long(4), priceCurrencyList);

        priceCurrencyList = new ArrayList<ProductItemPriceCurrency>();
        priceCurrencyList.add(new ProductItemPriceCurrency(100.00, "E-usd"));

        productPriceMap.put(new Long(5), priceCurrencyList);

    }

    public List<ProductItemPriceCurrency> getProductPriceCurrencyById(Long productId) {
        return productPriceMap.get(productId);
    }

    public void updatePrice(Long productId, ProductItemPriceCurrency productItemPriceCurrency) {
        List<ProductItemPriceCurrency> priceCurrencyList = getProductPriceCurrencyById(productId);

        for (int i = 0; i < priceCurrencyList.size(); i++) {
            ProductItemPriceCurrency priceCurrency = priceCurrencyList.get(i);

            if(priceCurrency.getCurrencyCode()
                    .equalsIgnoreCase(productItemPriceCurrency.getCurrencyCode())) {
                priceCurrency.setPrice(productItemPriceCurrency.getPrice());
                return;
            }
        }
    }

}