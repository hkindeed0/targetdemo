package com.example.demo;

import com.example.demo.model.ProductItemPriceCurrency;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.net.URISyntaxException;


@SpringBootTest
class ProductPriceApplicationTests {

	@Test
	void contextLoads() {
	}

	@Test
	public void testGetProductPrice_success() throws URISyntaxException
	{
		RestTemplate restTemplate = new RestTemplate();

		final String baseUrl = "http://localhost:8083/products/1/price";
		URI uri = new URI(baseUrl);

		ResponseEntity<String> result = restTemplate.getForEntity(uri, String.class);

		//Verify request succeed
		Assert.assertEquals(200, result.getStatusCodeValue());
		Assert.assertEquals(true, result.getBody().contains("priceCurrencyList"));

	}

	@Test
	public void testUpdateProductPrice_success() throws URISyntaxException
	{
		RestTemplate restTemplate = new RestTemplate();

		String baseUrl = "http://localhost:8083/products/5";
		URI uri = new URI(baseUrl);

		ProductItemPriceCurrency productItemPriceCurrency = new ProductItemPriceCurrency(20000.00, "E-usd");

		HttpHeaders headers = new HttpHeaders();
		headers.set("X-COM-PERSIST", "true");

		HttpEntity<ProductItemPriceCurrency> request = new HttpEntity<>(productItemPriceCurrency, headers);

		ResponseEntity<String> result = restTemplate.postForEntity(uri, request, String.class);


		//Verify request succeed
		Assert.assertEquals(200, result.getStatusCodeValue());

		// Check whether price has been updated
		baseUrl = "http://localhost:8083/products/5/price";
		uri = new URI(baseUrl);

		result = restTemplate.getForEntity(uri, String.class);

		//Verify request succeed
		Assert.assertEquals(200, result.getStatusCodeValue());
		Assert.assertEquals(true, result.getBody().contains("priceCurrencyList"));

		Assert.assertEquals(true, result.getBody().contains("20000"));
	}

}
